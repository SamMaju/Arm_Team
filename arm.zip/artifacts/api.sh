#!/bin/bash

sudo apt-get update 
sudo apt-get dist-upgrade -y
sudo apt-get install unzip -y
