# TAP - Azure Case Study

This repository contains the application code that's needed for the TAP - Azure Case Study